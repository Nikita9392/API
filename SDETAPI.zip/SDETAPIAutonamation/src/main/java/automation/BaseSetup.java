package automation;

import org.testng.annotations.Test;

public class BaseSetup {
	
  @Test
  public void beforeSuite() {
	  //RestAssured.baseURI = "http://postman-echo.com";
  }
  
  @Test
  public void afterSuite() {
	  
	 
  }
}
