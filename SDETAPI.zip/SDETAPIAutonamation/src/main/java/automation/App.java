package automation;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


/**
 * Hello world!
 *
 */
public class App extends BaseSetup {

	@Test(enabled = true)
	public void verifyGetRequest() {
		RestAssured.baseURI = "http://postman-echo.com";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET, "/get?foo1=bar1&amp;foo2=bar2");
		String responseBody = response.getBody().asString();
		System.out.println("Response from GET API is : " + responseBody);
	}
	
	@Test(enabled = true)
	public void verifyPostRequest() {
		RestAssured.baseURI = "http://postman-echo.com";
		RequestSpecification httpRequest = RestAssured.given().body("-");
		Response response = httpRequest.request(Method.POST, "/post");
		String responseBody = response.getBody().asString();
		System.out.println("Response from POST API is : " + responseBody);
	}
	
	@Test(enabled = true)
	public void verifyPutRequest() {
		RestAssured.baseURI = "http://postman-echo.com";
		RequestSpecification httpRequest = RestAssured.given().body("-");
		Response response = httpRequest.request(Method.PUT, "/put");
		String responseBody = response.getBody().asString();
		System.out.println("Response from PUT API is : " + responseBody);
	}
	
	@Test(enabled = true)
	public void verifyDeleteRequest() {
		RestAssured.baseURI = "http://postman-echo.com";
		RequestSpecification httpRequest = RestAssured.given().body("-");
		Response response = httpRequest.request(Method.DELETE, "/delete");
		String responseBody = response.getBody().asString();
		System.out.println("Response from DELETE API is : " + responseBody);
	}

}
